<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Design by http://www.rocketwebsitetemplates.com
Released for free under a Creative Commons Attribution 3.0 License
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>Prime Time</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<script type="text/javascript"> google.load('visualization', '1', {packages: ['corechart','table']}); </script>
</head>

<body>
<div class="main">

<!-- Header Information -->

<div class="header">
<div class="header_resize">
<div class="menu_nav">
</div>
<div class="logo"><h1><a href="index.html">Prime Time <small>when you need oligos, its time for primetime! (beta)</small></a></h1></div>
<div class="clr"></div>
</div>
</div>



<div class="content">
<div class="content_resize">

<!-- Main Body Information -->
<div class="mainbar">

<?php 
	include 'Config.php';
	
	$email_to = 'srikris@cs.wisc.edu';
	$today = strtotime("now");
	$email_subject = 'PrimeBug '.$today;
	$name = $_POST['name'];
	$email= $_POST['email'];
	$urgent = $_POST['urgent'];
	$bug = $_POST['bug'];
	$did = $_POST['did'];
	$actual = $_POST['actual'];
	$expected = $_POST['expected'];
	
	$email_message = "Form details below.\n\n";
	
	
	function clean_string($string) {
		$bad = array("content-type","bcc:","to:","cc:","href");
		return str_replace($bad,"",$string);
	}
	
	$email_message .= "First Name: ".clean_string($name)."\n";
	$email_message .= "Email: ".clean_string($email)."\n";
	$email_message .= "Urgent: ".clean_string($urgent)."\n";
	$email_message .= "Bug Report: ".clean_string($bug)."\n";
	$email_message .= "What I did: ".clean_string($did)."\n";
	$email_message .= "What I expected: ".clean_string($expected)."\n";
	$email_message .= "What I got: ".clean_string($actual)."\n";
	
	
	$headers = 'From: '.$email."\r\n".
	'Reply-To: '.$email."\r\n" .
	'X-Mailer: PHP/' . phpversion();
	mail($email_to, $email_subject, $email_message, $headers); 
	?>
	Thank you for filing a bug report. I will be in touch with you very soon.

</div>			

<!-- Sidebar Information -->

<div class="sidebar">

<div class="gadget">
<h2 class="star"><span>Search</span></h2><div class="clr"></div>
<ul class="sb_menu">
<li><a href="PrimeTime.html" title="Website Templates">Search oligos</a>
</ul>
</div>

<div class="gadget">
<h2 class="star"><span>Manage</span></h2><div class="clr"></div>
<ul class="ex_menu">
<li><a href="PrimeAdd.html" title="Website Templates">Add new oligos</a>
<li><a href="PrimeInfo.php" title="Website Templates">View oligo list</a>
<li><a href="PrimeLogInfo.php" title="Website Templates">View recent updates</a>
<li><a href="index.html" title="Website Templates">Download latest oligo list</a>
</ul>
</div>

<div class="gadget">
<h2 class="star"><span>Report</span></h2><div class="clr"></div>
<ul class="sb_menu">
<li><a href="BugReport.html" title="Website Templates">File a Bug/Suggestion</a>
</ul>
</div>




</div>
<div class="clr"></div>
</div>
</div>


<div class="footer">
<div class="footer_resize">
<p class="lf">Srikrishna Sridhar, Computer Sciences, University of Wisconsin-Madison </a> <span>Layout by Rocket <a href="http://www.rocketwebsitetemplates.com/">Website Templates</a></span></p>
<div class="clr"></div>
</div>
</div>
</div>
</body>
</html>


