<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Results</title>

<link rel="stylesheet" type="text/css" href="view.css" media="all">

<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<script type="text/javascript"> google.load('visualization', '1', {packages: ['corechart','table']}); </script>

<script type="text/javascript">


	// Load the Visualization API and the piechart package.
	google.load('visualization', '1', {'packages':['corechart','table']});
	
	// Set a callback to run when the Google Visualization API is loaded.
	google.setOnLoadCallback(drawChart);
	google.setOnLoadCallback(drawRevChart);
	
	// Callback that creates and populates a data table,instantiates the bar chart, passes in the data and draws it.
	function drawChart() {

	// Create our data table.
		var data = new google.visualization.DataTable();

		data.addColumn('string', 'Sl. No');
		data.addColumn('string', 'Name');
		data.addColumn('string', 'Date');
		data.addColumn('string', 'Predicted Tm');
		data.addColumn('string', 'Box');
		data.addColumn('string', 'Primer Sequence');
		
    	<?php  
		set_time_limit(5);
		include 'Config.php';
		
		$sequence = $_POST['sequence'];
		$name = $_POST['name'];
		$date = $_POST['date'];
		$melting = $_POST['melting'];		
		$box = $_POST['box'];
		$username = $_POST['username'];
		
		$query = "insert into PrimerTable values (";
		$query = $query."'".$sequence."',";
		$query = $query."'".$name."',";
		$query = $query."'date('".$date."')',";
		$query = $query."'".$melting."',";
		$query = $query."'".$box."');";
		

		$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'"');
		
		# Now print the database
		$query = "select name, date, melting, box, sequence from PrimerTable;";
		$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'" -m');
		
		echo $output;                  
		?>
	
		// Data Table Created	
		var table = new google.visualization.Table(document.getElementById('PrimerTable'));

    	// Draw Table after formatting
        table.draw(data, {width: '95%'});		
    	
	
	}// End of drawChart


</script>

	
</head>


<body id="main_body" >
	
	<img id="top" src="top.png" alt="">
	<div id="form_container">
	
	<h1><a>Input </a></h1>
	<form id="form_19072" class="appnitro" >
	
		<div class="form_description">
			<?php 
				include 'Config.php';
				$username = $_POST['username'];
				
				$query = "insert into LogTable values (";
				$query = $query."'".$username."',";
				$query = $query."datetime('now'))";
				$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'"');



				$query = "select * from LogTable where uDate like (select max(uDate) from LogTable)";

				$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'"');
				list($lastuser, $uDate) = split('[|]', $output);				
				
				echo "<h3>Primer Database : </h3> <br> Most recent update made by ".$lastuser." on ".$uDate."<br><br>";

			?>
		
		</div>			

		<li><div class="table_div" id="PrimerTable"></div></li>
	</form>
	
	<div id="footer">
		Srikrishna Sridhar - University of Wisconsin-Madison
	</div>
	
</div>
	 

	<img id="bottom" src="bottom.png" alt="">
	</body>
</html>
