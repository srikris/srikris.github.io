<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Results</title>

<link rel="stylesheet" type="text/css" href="view.css" media="all">
<script type="text/javascript" src="view.js"></script>

<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<script type="text/javascript"> google.load('visualization', '1', {packages: ['corechart','table']}); </script>

<script type="text/javascript">


	// Load the Visualization API and the piechart package.
	google.load('visualization', '1', {'packages':['corechart','table']});
	
	// Set a callback to run when the Google Visualization API is loaded.
	google.setOnLoadCallback(drawChart);
	google.setOnLoadCallback(drawRevChart);
	
	// Callback that creates and populates a data table,instantiates the bar chart, passes in the data and draws it.
	function drawChart() {

	// Create our data table.
		var data = new google.visualization.DataTable();

		data.addColumn('number', 'Sl. No');
		data.addColumn('string', 'Name');
		data.addColumn('number', 'Length');
		data.addColumn('number', 'Start Site');
		data.addColumn('string', 'Date');
		data.addColumn('string', 'Predicted Tm');
		data.addColumn('string', 'Box');
		data.addColumn('string', 'Sequence');
		
    	<?php  
		set_time_limit(5);
		include 'Config.php';
		
		$startPoint = $_POST['startPoint'];
		$endPoint = $_POST['endPoint'];
		$target = "dna/"; 
		$target = $target . basename( $_FILES['dnafile']['name']) ; 
		$output = shell_exec('python src/PrimerSearch.py -d "'.$target.'" -s '.$startPoint.' -e '.$endPoint);
		echo $output;                  
		?>
	
		// Data Table Created	
		var table = new google.visualization.Table(document.getElementById('ForwardPrimer'));

    	// Draw Table after formatting
        table.draw(data, {width: '95%'});		
    	
	
	}// End of drawChart


	</script>

<script type="text/javascript">


	// Load the Visualization API and the piechart package.
	google.load('visualization', '1', {'packages':['corechart','table']});
	google.load("jquery", "1.6.2");

	 
	// Set a callback to run when the Google Visualization API is loaded.
	google.setOnLoadCallback(drawRevChart);

// Callback that creates and populates a data table,instantiates the bar chart, passes in the data and draws it.
	function drawRevChart() {

	// Create our data table.
		var data = new google.visualization.DataTable();

		data.addColumn('number', 'Sl. No');
		data.addColumn('string', 'Name');
		data.addColumn('number', 'Length');
		data.addColumn('number', 'Start Site');
		data.addColumn('string', 'Date');
		data.addColumn('string', 'Predicted Tm');
		data.addColumn('string', 'Box');
		data.addColumn('string', 'Sequence');
		
        
       	<?php  
			include 'Config.php';
			$startPoint = $_POST['startPoint'];
			$endPoint = $_POST['endPoint'];
	     	$target = "dna/"; 
			$target = $target . basename( $_FILES['dnafile']['name']) ; 
			$output = shell_exec('python src/PrimerSearch.py -d "'.$target.'" -s '.$startPoint.' -e '.$endPoint. ' -r --del');
			echo $output;
			?>
	

		// Data Table Created	
		var table = new google.visualization.Table(document.getElementById('ReversePrimer'));

		// Draw Table after formatting
        table.draw(data, {width: '95%'});		

 		// set the width of the column with the title "Name" to 100px 
		 var title = "Sequence"; 
		 var width = "100px"; 
		 $('.google-visualization-table-th:contains(' + title + ')').css('width', width); 
    	
	
	}// End of drawRevChart
	</script>
	
</head>

<body id="main_body" >
	
	<img id="top" src="top.png" alt="">
	<div id="form_container">
	
	<h1><a>Input </a></h1>
	<form id="form_19072" class="appnitro" >
	
		<div class="form_description">
			<?php 
			include 'Config.php';
			$startPoint = $_POST['startPoint'];
			$endPoint = $_POST['endPoint'];
			$target = "dna/"; 
			$target = $target . basename( $_FILES['dnafile']['name']) ; 
			$ok=1; 
			if($_FILES['dnafile']['error']  == UPLOAD_ERR_OK) 
			{
				move_uploaded_file($_FILES['dnafile']['tmp_name'], $target);
				echo "<h2>Results : </h2> <br>
				Searched plasmid ".basename( $_FILES['dnafile']['name'])." for primers
				between position ".$startPoint." and ".$endPoint.". <br><br>";

			} 
			else
			{
				echo "<h2>File Upload Error <\h2>";
				
			}
			?>
		
		</div>			


		<h3>Forward Primer</h3>
		<li><div class="table_div" id="ForwardPrimer"></div></li>
        
    <h3>Reverse Primer</h3>
    <li><div class="table_div" id="ReversePrimer"></div></li> 
   
	<div class="form_description">
	<?php 
		
		$query = "select * from LogTable where uDate like (select max(uDate) from LogTable)";
		$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'"');
		list($lastuser, $uDate) = split('[|]', $output);				
	
		echo "<br><br> The database was most recently updated by ".$lastuser." on ".$uDate."<br><br>";
	?>
	</div>

	</form>

</div>	
	
	<div id="footer">
		Srikrishna Sridhar - University of Wisconsin-Madison
	</div>
	
</div>
	 

    <img id="bottom" src="bottom.png" alt="">
	</body>
</html>
