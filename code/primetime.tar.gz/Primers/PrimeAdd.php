<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Design by http://www.rocketwebsitetemplates.com
Released for free under a Creative Commons Attribution 3.0 License
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>Prime Time</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<script type="text/javascript"> google.load('visualization', '1', {packages: ['corechart','table']}); </script>

<script type="text/javascript">


// Load the Visualization API and the piechart package.
google.load('visualization', '1', {'packages':['corechart','table']});

// Set a callback to run when the Google Visualization API is loaded.
google.setOnLoadCallback(drawChart);
google.setOnLoadCallback(drawRevChart);

// Callback that creates and populates a data table,instantiates the bar chart, passes in the data and draws it.
function drawChart() {
	
	// Create our data table.
	var data = new google.visualization.DataTable();
	
	data.addColumn('string', 'Sl. No');
	data.addColumn('string', 'Name');
	data.addColumn('string', 'Date');
	data.addColumn('string', 'Predicted Tm');
	data.addColumn('string', 'Box');
	data.addColumn('string', 'Primer Sequence');
	
	<?php  
	set_time_limit(5);
	include 'Config.php';
	
	$sequence = $_POST['sequence'];
	$name = $_POST['name'];
	$date = $_POST['date'];
	$melting = $_POST['melting'];		
	$box = $_POST['box'];
	$username = $_POST['username'];
	
	$query = "insert into PrimerTable values (";
	$query = $query."'".$sequence."',";
	$query = $query."'".$name."',";
	$query = $query."'".$date."',";
	$query = $query."'".$melting."',";
	$query = $query."'".$box."');";
	
	
	$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'"');
	
	# Now print the database
	$query = "select name, date, melting, box, sequence from PrimerTable;";
	$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'" -m');
	echo $output;
	
	?>
	
	// Data Table Created	
	var table = new google.visualization.Table(document.getElementById('PrimerTable'));
	
	// Draw Table after formatting
	table.draw(data, {width: '95%'});		
	
	
}// End of drawChart


</script>


</head>

<body>
<div class="main">

<!-- Header Information -->

<div class="header">
<div class="header_resize">
<div class="menu_nav">
</div>
<div class="logo"><h1><a href="index.html">Prime Time <small>when you need oligos, its time for primetime! (beta)</small></a></h1></div>
<div class="clr"></div>
</div>
</div>



<div class="content">
<div class="content_resize">

<!-- Main Body Information -->
<div class="mainbar">



<form id="form_19072" class="appnitro" >

<div class="form_description">
<?php 
	include 'Config.php';

	$username = $_POST['username'];

	$query = "insert into LogTable values (";
	$query = $query."'".$username."',";
	$query = $query."datetime('now'))";
	$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'"');
	echo $output;
	
	
	$query = "select * from LogTable where uDate like (select max(uDate) from LogTable)";
	$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'"');
	list($lastuser, $uDate) = split('[|]', $output);				
	
	echo "<h3>Primer Database : </h3> <br> Most recent update made by ".$lastuser." on ".$uDate."<br><br>";
	
	?>

</div>			

<div class="table_div" id="PrimerTable"></div>
</form>

</div>

<!-- Sidebar Information -->

<div class="sidebar">

<div class="gadget">
<h2 class="star"><span>Search</span></h2><div class="clr"></div>
<ul class="sb_menu">
<li><a href="PrimeTime.html" title="Website Templates">Search oligos</a>
</ul>
</div>

<div class="gadget">
<h2 class="star"><span>Manage</span></h2><div class="clr"></div>
<ul class="ex_menu">
<li><a href="PrimeAdd.html" title="Website Templates">Add new oligos</a>
<li><a href="PrimeInfo.php" title="Website Templates">View oligo list</a>
<li><a href="PrimeLogInfo.php" title="Website Templates">View recent updates</a>
<li><a href="index.html" title="Website Templates">Download latest oligo list</a>
</ul>
</div>

<div class="gadget">
<h2 class="star"><span>Report</span></h2><div class="clr"></div>
<ul class="sb_menu">
<li><a href="BugReport.html" title="Website Templates">File a Bug/Suggestion</a>
</ul>
</div>

</div>
<div class="clr"></div>
</div>
</div>


<div class="footer">
<div class="footer_resize">
<p class="lf">Srikrishna Sridhar, Computer Sciences, University of Wisconsin-Madison </a> <span>Layout by Rocket <a href="http://www.rocketwebsitetemplates.com/">Website Templates</a></span></p>
<div class="clr"></div>
</div>
</div>
</div>
</body>
</html>


