
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Design by http://www.rocketwebsitetemplates.com
Released for free under a Creative Commons Attribution 3.0 License
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Prime Time</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<script type="text/javascript"> google.load('visualization', '1', {packages: ['corechart','table']}); </script>

<script type="text/javascript">


// Load the Visualization API and the piechart package.
google.load('visualization', '1', {'packages':['corechart','table']});

// Set a callback to run when the Google Visualization API is loaded.
google.setOnLoadCallback(drawChart);
google.setOnLoadCallback(drawRevChart);

// Callback that creates and populates a data table,instantiates the bar chart, passes in the data and draws it.
function drawChart() {
	
	// Create our data table.
	var data = new google.visualization.DataTable();
	
	data.addColumn('number', 'Sl. No');
	data.addColumn('string', 'Name');
	data.addColumn('number', 'Length');
	data.addColumn('string', 'Start Site');
	data.addColumn('string', 'Date');
	data.addColumn('string', 'Predicted Tm');
	data.addColumn('string', 'Box');
	data.addColumn('string', 'Sequence');
	
	<?php  
	set_time_limit(5);
	include 'Config.php';
	
	$startPoint = $_POST['startPoint'];
	$endPoint = $_POST['endPoint'];
	$target = "dna/"; 
	$target = $target . basename( $_FILES['dnafile']['name']) ; 
	$output = shell_exec('python src/PrimerSearch.py -d "'.$target.'" -s '.$startPoint.' -e '.$endPoint);
	echo $output;                  
	?>
	
	// Data Table Created	
	var table = new google.visualization.Table(document.getElementById('ForwardPrimer'));
	
	// Draw Table after formatting
	table.draw(data, {width: '95%'});		
	
	
}// End of drawChart


</script>

<script type="text/javascript">


// Load the Visualization API and the piechart package.
google.load('visualization', '1', {'packages':['corechart','table']});
google.load("jquery", "1.6.2");


// Set a callback to run when the Google Visualization API is loaded.
google.setOnLoadCallback(drawRevChart);

// Callback that creates and populates a data table,instantiates the bar chart, passes in the data and draws it.
function drawRevChart() {
	
	// Create our data table.
	var data = new google.visualization.DataTable();
	
	data.addColumn('number', 'Sl. No');
	data.addColumn('string', 'Name');
	data.addColumn('number', 'Length');
	data.addColumn('string', 'Start Site');
	data.addColumn('string', 'Date');
	data.addColumn('string', 'Predicted Tm');
	data.addColumn('string', 'Box');
	data.addColumn('string', 'Sequence');
	
	
	<?php  
	include 'Config.php';
	$startPoint = $_POST['startPoint'];
	$endPoint = $_POST['endPoint'];
	$target = "dna/"; 
	$target = $target . basename( $_FILES['dnafile']['name']) ; 
	$output = shell_exec('python src/PrimerSearch.py -d "'.$target.'" -s '.$startPoint.' -e '.$endPoint. ' -r --del');
	echo $output;
	?>
	
	
	// Data Table Created	
	var table = new google.visualization.Table(document.getElementById('ReversePrimer'));
	
	// Draw Table after formatting
	table.draw(data, {width: '95%'});		
	
	// set the width of the column with the title "Name" to 100px 
	var title = "Sequence"; 
	var width = "100px"; 
	$('.google-visualization-table-th:contains(' + title + ')').css('width', width); 
	
	
}// End of drawRevChart
</script>

</head>

<body>
<div class="main">

<!-- Header Information -->

<div class="header">
<div class="header_resize">
<div class="menu_nav">
</div>
<div class="logo"><h1><a href="index.html">Prime Time <small>when you need oligos, its time for primetime! (beta)</small></a></h1></div>
<div class="clr"></div>
</div>
</div>



<div class="content">
<div class="content_resize">

<!-- Main Body Information -->
<div class="mainbar">

<div class="form_description">
<?php 
	include 'Config.php';
	$startPoint = $_POST['startPoint'];
	$endPoint = $_POST['endPoint'];
	$target = "dna/"; 
	$target = $target . basename( $_FILES['dnafile']['name']) ; 
	$ok=1; 
	if($_FILES['dnafile']['error']  == UPLOAD_ERR_OK) 
	{
		move_uploaded_file($_FILES['dnafile']['tmp_name'], $target);
		echo "<h2>Search results</h2>
		Searched plasmid ".basename( $_FILES['dnafile']['name'])." for primers
		between position ".$startPoint." and ".$endPoint.".";	
	} 
	else
	{
		echo "<h2>File Upload Error <\h2>";
		
	}
	?>

</div>			

<div class="form_description">
<?php 
	
	$query = "select * from LogTable where uDate like (select max(uDate) from LogTable)";
	$output = shell_exec('python src/PrimerAdd.py -q "'.$query.'"');
	list($lastuser, $uDate) = split('[|]', $output);				
	
	echo "The database was most recently updated by ".$lastuser." on ".$uDate;
	echo "<br><br> <font color='red'> Note: </font> Multiple priming sites are shown seperated by commas in the start site column."
	?>
</div>


<h3>Forward Primer</h3>
<div class="table_div" id="ForwardPrimer"></div>

<h3>Reverse Primer</h3>
<div class="table_div" id="ReversePrimer"></div>

</form>



</div>

<!-- Sidebar Information -->

<div class="sidebar">

<div class="gadget">
<h2 class="star"><span>Search</span></h2><div class="clr"></div>
<ul class="sb_menu">
<li><a href="PrimeTime.html" title="Website Templates">Search oligos</a>
</ul>
</div>

<div class="gadget">
<h2 class="star"><span>Manage</span></h2><div class="clr"></div>
<ul class="ex_menu">
<li><a href="PrimeAdd.html" title="Website Templates">Add new oligos</a>
<li><a href="PrimeInfo.php" title="Website Templates">View oligo list</a>
<li><a href="PrimeLogInfo.php" title="Website Templates">View recent updates</a>
<li><a href="index.html" title="Website Templates">Download latest oligo list</a>
</ul>
</div>

<div class="gadget">
<h2 class="star"><span>Report</span></h2><div class="clr"></div>
<ul class="sb_menu">
<li><a href="BugReport.html" title="Website Templates">File a Bug/Suggestion</a>
</ul>
</div>

</div>
<div class="clr"></div>
</div>
</div>


<div class="footer">
<div class="footer_resize">
<p class="lf">Srikrishna Sridhar, Computer Sciences, University of Wisconsin-Madison </a> <span>Layout by Rocket <a href="http://www.rocketwebsitetemplates.com/">Website Templates</a></span></p>
<div class="clr"></div>
</div>
</div>
</div>
</body>
</html>
