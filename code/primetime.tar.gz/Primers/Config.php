<?php 

define("ERR_UPLOAD" , "0");
define("WEBSITE" , "http://10.129.16.70/~srikris/Primers/");


?>