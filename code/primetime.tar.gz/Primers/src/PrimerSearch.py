import csv
import string
import sys
import getopt
import commands

# String to reverse a DNA sequence
def reverseComp(seq):
	revCompSeq = ""
	for base in seq:
		if base == "A":
			revCompSeq += "T"
		if base == "T":
			revCompSeq += "A"
		if base == "G":
			revCompSeq += "C"
		if base == "C":
			revCompSeq += "G"
			
	return revCompSeq[::-1]
	
	
# Function to find all subsctrings
def find_all(str, sub, start, end):
	start = 0
	while True:
			start = str.find(sub, start, end)
			if start == -1: return
			yield start
			start += len(sub)

# ------------------------------------------------------------------------
#																Primer class
# ------------------------------------------------------------------------
	
# Primer Class
class Primer:

	# Initialize from individual data
	def __init___(self, seq, name, date, bp, rack):
		self.seq = seq
		self.revcompseq = reverseComp(seq)
		self.name = name
		self.date = date
		self.bp = bp
		self.rack = rack
		self.length = len(self.seq)
		
	# Initialize from list
	def initList(self, data):
		self.seq = string.upper(data[0])
		self.revcompseq = reverseComp(self.seq)
		self.name = data[1].replace("'" , "\\'")
		self.date = data[2]
		self.bp = data[3]	
		self.rack = data[4]	
		self.length = len(self.seq)
		
	# Display
	def display(self):
		print self.seq + "\t" + self.name + "\t" + self.date + "\t" + self.rack


# ------------------------------------------------------------------------
#																Primer list from DB
# ------------------------------------------------------------------------
# Primer List
def initPrimerList(filename):
	dataList = csv.reader(open(filename, 'rU'), dialect='excel')
	primerList = []
	dataList.next()	
	#Add Primer objects
	for data in dataList:
		p = Primer()
		p.initList(data)
		primerList.append(p)

	return primerList	

# ------------------------------------------------------------------------
#																Read DNA from file
# ------------------------------------------------------------------------
# Read the dna from the str file
def readStrFile(dnafile):
	
	dnafile = open(dnaFilename, 'r')
	contents = str(dnafile.readlines())

	# File format detection
	genbank = False
	strider = False
	if string.find(contents, "ORIGIN") != -1:
		genbank = True
	else:
		strider = True
		
	# The DNA is encoded after ORIGIN (Genbank Format)
	if (genbank == True):
		dnafile = open(dnaFilename, 'r')
		base = dnafile.readline()

		while base.find("ORIGIN") == -1:
			base = dnafile.readline()
			
			
		base = dnafile.read(1)
		dna=""
		while base != "":
			if string.find("ATGCatgc", base) != -1:
				dna += base
			base = dnafile.read(1)
	
	# Assume strider if you can't detect genbank format
	if (strider == True):
		founddna = False # Detects if you have found DNA
	
		dnafile = open(dnaFilename, 'r')
		base = dnafile.read(1)
		dna=""
		dnalist = []
	
		while base != "":
			if (string.find("ATGCatgc", base) != -1):
				dna += base
				founddna = True
	
			if (string.find("ATGCatgc", base) == -1) and (founddna == True):
				dnalist.append(dna)
				founddna = False
				
			base = dnafile.read(1)
			
		maxlength = 0
		for potentialdna in dnalist:
			if (len(potentialdna) > maxlength):
				dna = potentialdna
				maxlength = len(potentialdna)
	return dna

# ------------------------------------------------------------------------
#																Main function
# ------------------------------------------------------------------------

# Process arguments
opts, args = getopt.getopt(sys.argv[1:], "d:s:e:rc", ["dnafile", "start", "end", "rev", "del"])

# Default Value
start = 0
end = -1

# Search reverse or normal
rev = False

# Search circular DNA
deletefile = False
circular = False

# Exclude the first 10
excludefirstten = 0	
excludeBool = False

# Parse Arguments
for o, arg in opts:
	if o in ("-d", "--dnafile"):
		dnaFilename = arg
	if o in ("-s", "--start"):
		start = int(arg)
	if o in ("-e", "--end"):
		end = int(arg)
	if o in ("-r", "--rev"):
		rev = True
	if o in ("-c", "--del"):
		deletefile = True
	
# Database		
primerFilename = "src/PrimerList.csv"
dumpdir = "dna/" # Relative to Current
# Load the primerList
primerList = initPrimerList(primerFilename)

# Load the DNA
dna = readStrFile(dnaFilename)

# Logical start
start = start - 1
if end >0:
	end = end - 1
else:
	end = len(dna)-1

# Error Handling (Reseting)
if end >= len(dna):
	end = len(dna) - 1
if start < 1:
	start = 0

# This is circular only
if start > end:
	dna = dna[end:] + dna[0:start]
	circular = True
	
# Boom	
iter = 1


# Iterate through the list of primers
for primer in primerList:

	# Searching differnt things for rev sequence
	if rev == False:
		# This searches from the 3' to the 5' side
		primerSearch = string.upper(primer.seq)
	else:
		# This searches from the 5' to the 3' side
		primerSearch = string.upper(primer.revcompseq)

	# Searches for circular DNA
	
	if (circular == True):
		posList = list(find_all(string.upper(dna), primerSearch, 0, len(dna)))
		
	else:
		posList = list(find_all(string.upper(dna), primerSearch, start, end))

	# If you don't find it then return zero otherwise give the correct calculations
	if posList:
		if (circular == True and rev == False):			
			pos += (start + 1)%len(dna)
			
		elif (circular == True and rev == True):			
			pos += (start + len(primer.seq) + 1)%len(dna)
				
		else:
			posList = [pos+1 for pos in posList]
			pos = str(posList).strip('[]')
			
		# Give the output
		sys.stdout.write("data.addRow([%d, '%s', %d , '%s' ,'%s','%s','%s','%s']); \n" % 
		(iter, primer.name, primer.length, pos,  primer.date, primer.bp, primer.rack, primer.seq))
		iter = iter + 1




# ---------------------------------- Some old code for reverse search -----------------------#			
#	else:
#	
#		primerSearch = string.upper(primer.revcompseq)
#		if (circular == True):
#			pos = string.find(string.upper(dna), primerSearch , 0, len(dna))		
#
#		else:
#			pos = string.find(string.upper(dna), primerSearch , start, end)
#		
#		if  pos <> -1:
#			if (circular == True):
#				pos += (start + len(primer.seq) + 1)%len(dna)
#			else:
#				pos += len(primer.seq) + 1
#
#
#			sys.stdout.write("data.addRow([%d,'%s', %d , %d,'%s','%s','%s','%s']); \n" % 
#			(iter, primer.name, primer.length, pos,  primer.date,  primer.bp, primer.rack, primer.seq))
#			iter = iter + 1
