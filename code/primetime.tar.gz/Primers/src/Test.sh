sqlite3 PrimerDatabase.db <<SQL_ENTRY_TAG_1 .mode csv  select * from PrimerTable; SQL_ENTRY_TAG_1
