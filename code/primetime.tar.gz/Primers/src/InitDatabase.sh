DB_NAME=PrimerDatabase.db
rm -f $DB_NAME

sqlite3 $DB_NAME <<SQL_ENTRY_TAG_1
create table PrimerTable ( sequence text, name text, date text, melting text, box text );
SQL_ENTRY_TAG_1

sqlite3 $DB_NAME <<SQL_ENTRY_TAG_2
create table LogTable ( user text, udate text );
SQL_ENTRY_TAG_2

sqlite3 $DB_NAME <<SQL_ENTRY_TAG_3
.separator ","
.import PrimerList.csv PrimerTable
SQL_ENTRY_TAG_3

chmod 777 $DB_NAME
