import csv
import string
import sys
import getopt
import commands

# Define the primer class
class obj:
	
	# Initialize from individual data
	def __init___(self, data, length):
		self.data = data
		self.length = length
	
	# Initialize from list
	def initList(self, data):
		self.data = data
		self.length = len(data)
	
	# Display
	def googleDisplay(self,iter):
		output = "data.addRow(['"+str(iter)+"'"
		for i in range(self.length):
			output += ",'"+str(self.data[i])+"'"
		output += "]);"

		return output

# Return a list from the SQL output
def makeList(output):
	primerList = []
	elements = output.split('\n')
	
	# Add primer objects to the list
	for element in elements:
		p = obj()
		p.initList(element.split('|'))
		primerList.append(p)
		
	# Return a list of primer objects
	return primerList

#sys.stdout.write("data.addRow(['%d', '%s','%s','%s','%s','%s']); \n" % (iter, primer.name, primer.date, primer.mp, primer.box, primer.seq))

#------------------------------- Start Here ------------- #

# Process arguments
opts, args = getopt.getopt(sys.argv[1:], "q:m", ["query", "modify"])


# Set the option to modify the data stream
modifyData = False;

# Parse Arguments
for o, arg in opts:
	if o in ("-q", "--query"):
		query = arg
	if o in ("-m", "--modify"):
		modifyData = True;

# Database		
primerDatabase = "src/PrimerDatabase.db"

# Execute the query command
queryCommand = 'sqlite3 -list '+primerDatabase+' \"'+query+'\"'
output = commands.getoutput(queryCommand)


# Modify the output stream depending on options
if modifyData == 1:
	objList = makeList(output)
	# Boom	
	for iter in range(len(objList)):
		obj = objList[iter]	
		sys.stdout.write(obj.googleDisplay(iter+1))
else:
	print output