* Need to add gams to the path for the Makefile to work


------------------- Data cleaning notes -------------------
* Gams does not accept spaces in the names. They have been replaces with underscores. 
* Gams does not accept some special chracters line :. They have been removed.
* The makefile adds a data dire`ctory directory, change the path (I could have done a better job with this)


 
------------------- Performance tuning -------------------
* Output must also be cleaned to replace '_' with ' '
* Check out output/status.csv and it gives you an idea of how the relative weight of the objective function is set.
