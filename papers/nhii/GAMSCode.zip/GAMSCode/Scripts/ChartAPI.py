# Generates basic HTTP Command for the Google Chart API

url="http://chart.apis.google.com/chart"+ \
"?chxl=1:|Agents"+ \
"&chxp=1,50"+ \
"&chxs=0,676767,11.5,0,lt,676767"+ \
"&chxtc=0,5"+ \
"&chxt=x,y"+ \
"&chbh=a"+ \
"&chbh=a,15,0"+ \
"&chs=620x400"+ \
"&cht=bhg"+ \
"&chco=4D89F9,FF9900,FF0000,008000,49188F,00FF00,FFCC33,000000,C3D9FF,C2BDDD,3366CC,80C65A,CA2D2DF2,008000"+ \
"&chd=t:2.772|3.141|36.149|0.058|0.056|0.058|0.188|0.057|0.056|57.267|0|0|0|0|0"+ \
"&chdl=Aurora|St+Mary|St+Francis|Community+Care|Compcare|Humana|MHIC|WPS|United+Health|Lab|Govt|ICHP|AHP|CCHP|MHS"+ \
"&chtt=Relative+worth+of+WHIE+Information"+\
"&chts=676767,20"

print url
