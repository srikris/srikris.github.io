# Writes a GAMS input file for Threhold Percentage for Agents
# Input Argument = Threhold Percentage for profits ('From web form').
#The script is called from the web form using an input argument
import sys

	
#Input File Path for the .inc file 
GamsInputFilePath = sys.argv[1]; 
GamsInput = sys.argv[2];


#Hospital

# Defines an Empty Agent String List
#class Agent:
    #def __init__(self, Name, Threshold):
        #self.n = Name
        #self.t = Threshold

#class AgentList:
	#def __init__(self, Name, Threshold):
        #self.data = []
	#def add(self, x):
        #self.data.append(x)
		
		
# Appends all the agent names to the String list
Agents.append('Aurora');
Agents.append('StMary');
Agents.append('StFrancis');
Agents.append('CommunitiyCare');
Agents.append('Compcare');
Agents.append('Humana');
Agents.append('MHIC');
Agents.append('WPS');
Agents.append('UnitedHealthCare');
Agents.append('Lab');
Agents.append('Govt');
Agents.append('ICHP');
Agents.append('AHP');
Agents.append('CCHP');
Agents.append('MHS');
Agents.append('WHIE');
Agents.append('Medicare');
Agents.append('Medicaid');
Agents.append('SelfPay');

#Opens a file in write mode
GamsInputFile = open(GamsInputFilePath, 'w')

# Writes the Input to the Gams File in the .inc format
for Agent in set(Agents):
	GamsInputFile.write(Agent)
	GamsInputFile.write(' ')
	GamsInputFile.write(str(GamsInput))
	GamsInputFile.write('\n')

