----------------------------------------------------------------------
This software is used to aid the study titled
----------------------------------------------------------------------
A Robust Framework for Quantifying the Financially Realizable worth of
Health Information Exchanges

Supported by a grant from the National Library of Medicine, LM  8949    

-----------------------------------------------------------------------
Version : 1.0

Date of Release: 
September 20, 2010

Authors:
Srikrishna Sridhar, Stephen Wright 
University of Wisconsin, Madison
       
-----------------------------------------------------------------------
Contact:
Srikrishna Sridhar
srikris@cs.wisc.edu
http://pages.cs.wisc.edu/~srikris/

Stephen Wright
swright@cs.wisc.edu
http://pages.cs.wisc.edu/~swright/

Bug Fixing
srikris@cs.wisc.edu (bugs, problems, questions)

-----------------------------------------------------------------------
The Readme file is organized as follows

1. Introduction
2. Dependencies
3. How to run the code
4. Software Organization
5. Data File Standards
6. Analytic Scripts



-----------------------------------------------------------------------
1. Introduction
-----------------------------------------------------------------------
The following software was written at University of Wisconsin, Madison 
to aid research work that seeks to quantify the financially realizable 
worth of Health Information Exchanges (HIE). The code is primarily written 
in GAMS. (http://www.gams.com/)

The General Algebraic Modeling System (GAMS) is a high-level modeling system 
for mathematical programming and optimization. It consists of a language 
compiler and a stable of integrated high-performance solvers. GAMS was chosen 
because it offers robustness interms of varied solver choice. The software 
consists of an encoding of a Linear Program model of the Health care system. 


-----------------------------------------------------------------------
2. Dependencies
-----------------------------------------------------------------------
The software requires a license of GAMS. Details about GAMS installations 
is available at (http://support.gams-software.com/doku.php)

No prior installations or dependencies are reuired for running this software.

-----------------------------------------------------------------------
3. How to run the code
-----------------------------------------------------------------------
The Makefile is automatically designed to run the code on the data set.
Since GAMS is not a compiler, there is no notion of executable code. 

The Makefile automatically runs the file titled LinearModel.gms with 
the output in the list file titled LinearModel.lst

Version 1.0 does not truncate the output. Future versions should have 
options to regulate output.

------------------------------------------------------------------------
4. Software Organization
------------------------------------------------------------------------
The files and their descriptions are given as follows (Directory wise)

	Scripts (Consists of Scrpits for Data Analytics)
		Version 1.0 has no scripts as of now. Scripts shall be updated 
        in Version 2.0 for sensitivity analysis of each paramter. 
        They can also be used to produce aggregated data files and plots.
		
	Data (Data Files)
		DataDefinitions.gms - Contains the domain for the sample data set
		DataAssignment.gms  - Assigns all Aggregated data from the sample 
                              data set
		
	LinearModel.gms - Encoded Linear model 
	Solve.gms		- Calls Model files
	Parameters.gms  - List of Tunable parameters that govern the model
		
	
	
-------------------------------------------------------------------------
5. Data File Standards
-------------------------------------------------------------------------

All the current data files are directly encoded into our GAMS files. 
The GAMS syntax to change data is available here
(http://www.gams.com/dd/docs/bigdocs/GAMSUsersGuide.pdf).

Currently, data is only available in one Data file. Future versions will 
have scripts to upload complete data sets.

-------------------------------------------------------------------------
6. Analytical Scripts
-------------------------------------------------------------------------

The analytical scripts available in the Scripts directory are used for 
sensitivity analysis of the tunable paramters of model. Version 2.0 and 
up will have these updates.





